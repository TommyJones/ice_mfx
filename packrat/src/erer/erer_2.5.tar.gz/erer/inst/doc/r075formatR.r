***********************************************************
** Title: This is an exercise for formatting R codes. *****
***********************************************************
__________ 1. Load packages and data ____________
      library( erer );data( daIns );
 2. Create a dataset from the existing one
 mydata<-    daIns[ ,1:5 ]; head(  mydata); names(mydata );str( mydata); summary(mydata); 
 3. Run a linear model ----------------------------------
 result=lm(formula=Y~Injury+HuntYrs+Nonres
+Lspman
,data 
= mydata)
  summary( result );####This is the main result.