# Input data
Examine dependent and independent variable names and raw data
Extract variables from data
Transform variables into matrix

# Transformation
Compute coefficients
Compute fitted values
Compute residuals
Compute sigma
Compute variance and standard errors
Compute t-values
Compute p-values

# Outputs
Report coefficients, standard errors, t-values, and p-values