summary.dice = function(object, ...){
	print(object, ...)
}
