summary.ice = function(object,...){
	print(object,...)
}
